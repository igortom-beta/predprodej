# Lojzovy Paseky AI Assistant - Complete Deployment Guide

## Project Overview

A production-ready multilingual AI assistant for rental property management with:
- **7-language support**: Czech, German, English, Croatian, Italian, French, Spanish
- **GPT-4o powered**: Real-time AI responses
- **Real-time pricing**: Dynamic rent calculations with live CZK/EUR exchange rates
- **Floating UI**: Non-intrusive chat widget in bottom-right corner
- **Responsive design**: Fully mobile-optimized

## Quick Start

### Prerequisites
```bash
Node.js 18+
npm or pnpm package manager
OpenAI API key
GitHub account
```

### Installation
```bash
# Clone the repository
git clone https://github.com/igortom-beta/lojzovypaseky.git
cd lojzovypaseky

# Install dependencies
pnpm install

# Set environment variables
export OPENAI_API_KEY="your-api-key-here"

# Run development server
pnpm dev

# Run tests
pnpm test

# Build for production
pnpm build
```

## Deployment Options

### Option 1: Vercel (Recommended)

**Advantages**: Automatic scaling, serverless functions, free tier available

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables in Vercel dashboard
# OPENAI_API_KEY = your-key
```

**Vercel Configuration** (`vercel.json`):
```json
{
  "buildCommand": "pnpm build",
  "outputDirectory": "dist",
  "env": {
    "OPENAI_API_KEY": "@openai_api_key"
  }
}
```

### Option 2: Netlify

**Advantages**: Easy GitHub integration, free SSL, generous free tier

```bash
# Install Netlify CLI
npm i -g netlify-cli

# Deploy
netlify deploy --prod

# Or connect GitHub for automatic deployments
```

**Netlify Configuration** (`netlify.toml`):
```toml
[build]
  command = "pnpm build"
  functions = "server"
  publish = "dist"

[env]
  OPENAI_API_KEY = "your-api-key"
```

### Option 3: GitHub Pages + External Backend

For static hosting with external API:

```bash
# Build frontend only
pnpm build

# Push dist folder to gh-pages branch
git subtree push --prefix dist origin gh-pages
```

## Environment Variables

Required for production:
```
OPENAI_API_KEY=sk-proj-...
DATABASE_URL=mysql://...  (optional, for chat history)
JWT_SECRET=your-secret
```

## Core Components

### Backend (tRPC)

**File**: `server/routers.ts`

```typescript
ai: router({
  chat: publicProcedure
    .input(z.object({
      messages: z.array(z.object({
        role: z.enum(['user', 'assistant']),
        content: z.string(),
      })),
      language: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      // Fetches exchange rate from Czech National Bank
      // Calls GPT-4o with system prompt
      // Returns AI response + current EUR rate
    }),
  
  getExchangeRate: publicProcedure
    .query(async () => {
      // Returns current CZK/EUR exchange rate
    }),
})
```

### Frontend Component

**File**: `client/src/components/FloatingChatWidget.tsx`

- Floating chat window (bottom-right, z-index: 50)
- Green "REZERVOVAT TEĎ" button (z-index: 40)
- Automatic language detection from user input
- Responsive design (works on all screen sizes)
- Message history with auto-scroll
- Loading states with animated dots

### System Prompt

The AI is instructed to:
1. Detect user language from conversation
2. Respond in user's native language
3. Calculate rent: 24,000 CZK/month
4. Calculate deposit: 2 months rent (48,000 CZK)
5. Convert to EUR using live CNB rate
6. Provide professional, friendly, sales-oriented responses
7. Offer booking and contact information

## Language Detection

The system uses keyword matching to detect language:

```typescript
const languageKeywords = {
  cs: ['ahoj', 'jak', 'co', 'kde', 'kdy', 'proč', 'cena', ...],
  de: ['wie', 'was', 'wo', 'wann', 'warum', 'bungalow', ...],
  en: ['how', 'what', 'where', 'when', 'why', 'bungalow', ...],
  hr: ['kako', 'što', 'gdje', 'kada', 'zašto', 'bungalov', ...],
  it: ['come', 'cosa', 'dove', 'quando', 'perché', 'bungalow', ...],
  fr: ['comment', 'quoi', 'où', 'quand', 'pourquoi', 'bungalow', ...],
  es: ['cómo', 'qué', 'dónde', 'cuándo', 'por qué', 'bungalow', ...],
}
```

## API Integration

### OpenAI API

- **Model**: GPT-4o
- **Endpoint**: Handled by `invokeLLM()` helper
- **Security**: API key stored server-side only

### Czech National Bank API

- **Endpoint**: `https://www.cnb.cz/en/financial-markets/foreign-exchange-market/central-bank-exchange-rate-fixing/central-bank-exchange-rate-fixing/daily.txt`
- **Rate**: Updated daily
- **Fallback**: 24.5 CZK/EUR if API fails

## Testing

```bash
# Run all tests
pnpm test

# Test coverage
pnpm test -- --coverage

# Watch mode
pnpm test -- --watch
```

**Test Files**:
- `server/auth.logout.test.ts` - Authentication tests
- `server/ai.chat.test.ts` - AI chat and exchange rate tests

## Performance Optimization

1. **Lazy loading**: Chat widget loads on demand
2. **Message streaming**: Markdown rendering with Streamdown
3. **Caching**: Exchange rate cached per request
4. **Minification**: Production build optimized

## Security Considerations

1. **API Key Protection**: Never exposed to client
2. **CORS**: Configured for specific origins
3. **Input Validation**: Zod schema validation
4. **Rate Limiting**: Implement on production
5. **HTTPS**: Required for production

## Monitoring & Logging

Add monitoring for:
- API response times
- Error rates
- User language distribution
- Booking conversion rates

## Troubleshooting

### Chat not responding
- Check OpenAI API key is valid
- Verify API key has sufficient credits
- Check network connectivity

### Exchange rate not updating
- Verify CNB API is accessible
- Check fallback rate is applied
- Monitor API response times

### Language detection issues
- Add more keywords to detection algorithm
- Consider using language detection library
- Log detected language for debugging

## Maintenance

### Regular Tasks
- Monitor API usage and costs
- Update dependencies monthly
- Review and optimize prompts
- Analyze user conversations for improvements

### Backup & Recovery
- Database backups (if using chat history)
- Code repository backups
- API key rotation schedule

## Support & Documentation

- **GitHub Issues**: Report bugs
- **Documentation**: See README.md
- **API Docs**: See server/routers.ts comments

## License

MIT License - See LICENSE file

---

**Last Updated**: January 2026
**Version**: 1.0.0
**Status**: Production Ready
